ROCK PAPER SCISSOR GAME
TEAM JOBS

This the rock paper scissor game of team jobs,IIC

To run the game, open index.html
The preferred browser is Chrome

The code for the central part of the game in written in single.html

Only the algorithm of the program is written in python within the 50 line limit and the rest part of the game,i.e,the controlling and GUI part are written in 
javascript as prescribed in the problem statement.This code can be found in single.html.
(Python is only used to write the algorithm,i.e,who wins and who loses and not used in the game engine as per problem statement.Python program runs in the backgroung where
as javascript runs in the frontend.Brython was used to write the the python program within the html file.)

Instruction

when you play, first you have to select the hand gesture you want to use(rock,paper or scissors) and then hit play button
to get the result.Based on who wins the score will be shown
